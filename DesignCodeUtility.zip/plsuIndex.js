#!/usr/bin/env node

return require("./src/plsuMain").main(process.argv)
